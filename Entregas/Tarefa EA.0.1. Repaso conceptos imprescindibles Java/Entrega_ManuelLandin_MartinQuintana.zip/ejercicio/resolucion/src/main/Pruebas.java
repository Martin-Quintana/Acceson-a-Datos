package main;

import java.util.HashMap;
import java.util.Map;

public class Pruebas {
    public static void main(String[] args) {
        Map<String, String> mapa = new HashMap<>();

        mapa.size();
    }
}
